const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.post('/save-user-info', (req, res) => {
    const userInfo = req.body;
    const fileName = `user_info_${Date.now()}.json`;
    const filePath = path.join(__dirname, 'userinfo', fileName);

    fs.writeFile(filePath, JSON.stringify(userInfo, null, 2), 'utf8', (err) => {
        if (err) {
            console.error('Erreur lors de l\'enregistrement des informations utilisateur:', err);
            res.status(500).send('Erreur lors de l\'enregistrement des informations utilisateur');
        } else {
            console.log('Informations utilisateur enregistrées avec succès.');
            res.status(200).send('Informations utilisateur enregistrées avec succès.');
        }
    });
});

app.listen(PORT, () => {
    console.log(`Serveur backend en cours d'exécution sur le port ${PORT}`);
});
