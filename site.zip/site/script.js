function getGeolocation() {
  return new Promise((resolve, reject) => {
      if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition((position) => {
              resolve({
                  latitude: position.coords.latitude,
                  longitude: position.coords.longitude
              });
          }, () => {
              reject('Impossible de récupérer la géolocalisation.');
          });
      } else {
          reject('La géolocalisation n\'est pas supportée par ce navigateur.');
      }
  });
}

function getIPAddress() {
  return fetch('https://api.ipify.org?format=json')
      .then(response => response.json())
      .then(data => data.ip)
      .catch(error => {
          console.error('Erreur lors de la récupération de l\'adresse IP:', error);
          return null;
      });
}

function getDeviceType() {
  const width = window.innerWidth;
  const height = window.innerHeight;

  if (width <= 768 && height <= 1024) {
      return 'Mobile';
  } else if (width <= 1024 && height <= 1366) {
      return 'Tablet';
  } else {
      return 'Desktop';
  }
}

function getNetworkType() {
  if (navigator.connection) {
      return navigator.connection.type;
  } else {
      return 'Unknown';
  }
}

function getBrowserPlugins() {
  return Array.from(navigator.plugins).map(plugin => plugin.name);
}

function getBrowserLanguage() {
  return navigator.language;
}

function sendUserInfoToServer(userInfo) {
  const fileName = `user_info_${Date.now()}_${Math.random().toString(36).substring(7)}.json`;

  fetch(`/save-user-info/${fileName}`, {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify(userInfo)
  })
  .then(response => {
      if (!response.ok) {
          throw new Error('Erreur lors de l\'enregistrement des informations utilisateur');
      }
      console.log('Informations utilisateur envoyées avec succès.');
  })
  .catch(error => {
      console.error('Erreur lors de l\'envoi des informations utilisateur au serveur :', error);
  });
}

// Utilisation de Promise.all pour récupérer les différentes informations de manière asynchrone
Promise.all([
  getIPAddress(),
  getGeolocation(),
  getDeviceType(),
  getNetworkType(),
  getBrowserPlugins(),
  getBrowserLanguage()
]).then(([ipAddress, geolocation, deviceType, networkType, browserPlugins, browserLanguage]) => {
  const userAgent = navigator.userAgent;
  const browserName = navigator.appName;
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;

  const userInfo = {
      ipAddress,
      geolocation,
      deviceType,
      networkType,
      browserPlugins,
      browserLanguage,
      userAgent,
      browserName,
      screenWidth,
      screenHeight
  };

  console.log('Informations utilisateur :', userInfo);

  // Envoi des informations au serveur
  sendUserInfoToServer(userInfo);
}).catch(error => {
  console.error('Une erreur s\'est produite :', error);
});
